<h1>Menu Soal : </h1><br>

<a href="array_loop.php">Array Loop</a><br>
<a href="mysql_query.php">Mysql Query</a><br>
<a href="operator_logic.php">Operator Logic</a><br>
<a href="looping_condition.php">Looping Condition</a><br>

<a href="../index.php">Menu Utama</a>