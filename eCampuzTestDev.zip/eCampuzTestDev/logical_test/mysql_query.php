<!-- /*
    Bismillah
    www.ecampuz.com
    eCampuz Test Web Developer 1 
    Peserta Test : Muhammad Khoirul Bakhtiar
    Tanggal Mengerjakan Kode Ini : 15 September 2021 9:25 
*/ -->

<h1>Mysql Query</h1>
<h3>Soal:</h3>
<p>Buatlah sebuah query untuk menampilkan nama mahasiswa yang memiliki nilai mata kuliah tertinggi pada mata kuliah dengan kode “MK303”.</p>
<table>
    <tr>
        <td><img src="assets/images/tb_mahasiswa.jpg" width="300px;"></td>
        <td><img src="assets/images/tb_mahasiswa_nilai.jpg" width="200px;"></td>
        <td><img src="assets/images/tb_matakuliah.jpg" width="370px;"></td>
    </tr>
</table>
<h3>Jawaban:</h3>
<table border="1">
    <tr>
        <td>No.</td>
        <td>Nama</td>
        <td>Kelas</td>
        <td>Jurusan</td>
        <td>Tahun</td>
    </tr>
<?php
    include "inc/connection.php";
    
    $query = mysqli_query($conn, "SELECT tb_mahasiswa.mhs_nama,tb_mahasiswa_nilai.nilai, tb_matakuliah.mk_nama, tb_matakuliah.mk_kode FROM tb_mahasiswa 
        INNER JOIN tb_mahasiswa_nilai ON tb_mahasiswa.mhs_id = tb_mahasiswa_nilai.mhs_id 
        INNER JOIN tb_matakuliah ON tb_mahasiswa_nilai.mk_id = tb_matakuliah.mk_id
        WHERE tb_matakuliah.mk_kode = 'MK303'
        ORDER BY tb_mahasiswa_nilai.nilai DESC");

        $no = 1;
        foreach ($query as $row) :
    ?>

    <tr>
        <td><?= $no++; ?></td>
        <td><?= $row['mhs_nama']; ?></td>
        <td><?= $row['mk_kode']; ?></td> 
        <td><?= $row['mk_nama']; ?></td> 
        <td><?= $row['nilai']; ?></td> 
    </tr>

    <?php endforeach; ?>

</table>

<br>
<a href="index.php" style="padding:10px;"><< Kembali</a>
