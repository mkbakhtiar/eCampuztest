<!-- /*
    Bismillah
    www.ecampuz.com
    eCampuz Test Web Developer 1 
    Peserta Test : Muhammad Khoirul Bakhtiar
    Tanggal Mengerjakan Kode Ini : 15 September 2021 8:55 
*/ -->

<div>
    <h1>Array Loop - Logical Test</h1>
    <h3>Soal :</h3>
    <p>Lanjutkan skrip berikut dengan menggunakan perulangan while untuk menampilkan semua data pada array ke web browser</p>
    <img src="assets/images/array_loop.jpg" width="200px">
    <h3>Jawaban :</h3>
    <table>
    <tr>
        <td>
            PHP Code:
            <pre style="background:lightgray;padding:10px;font-family:courier new;font-size:12px;">
//Define data aplikasi in array
$eCAplikasi = array("gtAkademik", "gtFinansi", "gtPerizinan","eCampuz","e0viz");
//set array length
$countArray = count($eCAplikasi);

//menampilkan data tiap element using while

//Define var $x
$x=0;
while($x < $countArray) {
    //menampilkan pesan sesuai perulangan, dan elemen array sesuai index loop
    echo "The aplikasi is: $eCAplikasi[$x] < br>";

    $x++;

}
            </pre>    
        </td>
    </tr>
    <tr>
        <td>
            Result: <br>
            <?php
                //Define data aplikasi in array
                $eCAplikasi = array("gtAkademik", "gtFinansi", "gtPerizinan","eCampuz","e0viz");
                //set array length
                $countArray = count($eCAplikasi);

                //menampilkan data tiap element using while

                //Define var $x
                $x=0;
                while($x < $countArray) {
                    //menampilkan pesan sesuai perulangan, dan elemen array sesuai index loop
                    echo "The aplikasi is: $eCAplikasi[$x] <br>";

                    $x++;
                
                }

            ?>

        </td>
    
    </tr>
</table>
<br>
<a href="index.php" style="padding:10px;"><< Kembali</a>
    
    
</div>

