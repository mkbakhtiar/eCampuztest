Pembagian 7:2 tanpa operator div dan / <br>
<pre style="background:lightgray;padding:10;font-size:12px;font-family:courier new">
function pembagian($num, $bagi){

    if($num<$bagi){
        return 0;
    }        
    else{
         return 1+pembagian($num-$bagi, $bagi);
    }
    
        
}
</pre>
<?php


function pembagian($num, $bagi){

    if($num<$bagi){
        return 0;
    }        
    else{
         return 1+pembagian($num-$bagi, $bagi);
    }
    
        
}

echo "Hasil : ". pembagian(7,2);

?>
<a href="index.php" style="padding:10px;"><< Kembali</a>
