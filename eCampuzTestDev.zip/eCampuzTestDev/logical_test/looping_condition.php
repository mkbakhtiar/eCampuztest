<h1>Looping Condition</h1>
<h3>Soal:</h3>

<p>

Buatlah sebuah program yang mencetak angka dari 1 sampai dengan 50, dengan ketentuan sebagai berikut:<br>
<ul>
    <li>Jika angka yang akan tercetak merupakan kelipatan tiga, maka program akan mencetak kata “Foo”</li>
    <li>Jika angka yang akan tercetak merupakan kelipatan lima, maka program akan mencetak kata “Bar”</li>
    <li>Jika angka yang akan tercetak merupakan kelipatan tiga dan lima sekaligus, maka program akan mencetak kata “FooBar”.</li>
</ul>




</p>

<h3>Jawaban:</h3>
<?php

$x=1;
while($x < 50) {
    
    if($x % 3 == 0 AND $x % 5 == 0){
        echo "Bilangan ".$x. " adalah : FooBar <br>";
    }else{
        if($x % 3 == 0){
            echo "Bilangan ".$x. " adalah : Foo <br>";
        }else if($x % 5 == 0){
            echo "Bilangan ".$x. " adalah : Bar <br>";
        }
    }

    $x++;

}

?>
<a href="index.php" style="padding:10px;"><< Kembali</a>