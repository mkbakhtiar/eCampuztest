<!-- /*
    Bismillah
    www.ecampuz.com
    eCampuz Test Web Developer 1 
    Peserta Test : Muhammad Khoirul Bakhtiar
    Tanggal Mengerjakan Kode Ini : 15 September 2021 9:25 
*/ -->
<?php 

$conn = mysqli_connect("localhost","root","","ecampuz");

// Check connection
if (mysqli_connect_errno()){
	echo "Koneksi database gagal : " . mysqli_connect_error();
}else{
    // echo "Koneksi Berhasil";
}

?>