<div style="background:orange;padding:25px;width:500px;">
    <p>Cari Instansi<p>

    <form methos="GET" action="home.php">
        <input type="text" name="cari"> <input type="submit" value="Cari">
    </form>

    <h3>Data Instansi</h3>
    <table border="1">
        <tr>
            <td>No.</td>
            <td>Nama Instansi</td>
            <td>Deskripsi</td>
            <td>Aksi</td>
        </tr>
    <?php
        include "../logical_test/inc/connection.php";
        

        if(isset($_GET['cari'])){
            $carii=$_GET['cari'];
            $query = mysqli_query($conn, "SELECT * from tb_instansi WHERE ins_nama LIKE '%$carii%'");
        }else{
            $query = mysqli_query($conn, "SELECT * from tb_instansi");
        }
        
        

            $no = 1;
            foreach ($query as $row) :
        ?>

        <tr>
            <td><?= $no++; ?></td>
            <td><?= $row['ins_nama']; ?></td>
            <td><?= $row['ins_deskripsi']; ?></td> 
            <td> <a href="ubah.php?id=<?=$row['id']?>">Ubah</a> | <a href="hapus.php?id=<?=$row['id']?>">Delete</a></td> 
        </tr>

        <?php endforeach; ?>

    </table>
</div>