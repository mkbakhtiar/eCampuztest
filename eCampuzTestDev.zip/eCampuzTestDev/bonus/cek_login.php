<?php 

session_start();


include "../logical_test/inc/connection.php";


$username = $_POST['username'];
$password = $_POST['password'];


$data = mysqli_query($conn,"select * from tb_user where us_username='$username' and us_password='$password'");


$cek = mysqli_num_rows($data);

if($cek > 0){
	$_SESSION['username'] = $username;
	$_SESSION['status'] = "login";
	header("location:home.php");
}else{
	header("location:index.php?pesan=gagal");
}
?>