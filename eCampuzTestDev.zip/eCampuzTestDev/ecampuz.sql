/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50724
 Source Host           : localhost:3306
 Source Schema         : ecampuz

 Target Server Type    : MySQL
 Target Server Version : 50724
 File Encoding         : 65001

 Date: 15/09/2021 11:00:47
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_instansi
-- ----------------------------
DROP TABLE IF EXISTS `tb_instansi`;
CREATE TABLE `tb_instansi`  (
  `ins_id` int(10) NOT NULL AUTO_INCREMENT,
  `ins_nama` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `ins_deskripsi` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  PRIMARY KEY (`ins_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_instansi
-- ----------------------------
INSERT INTO `tb_instansi` VALUES (1, 'ecampuz', 'Software Kampus');
INSERT INTO `tb_instansi` VALUES (2, 'Gamatechno', 'Sofware House');

-- ----------------------------
-- Table structure for tb_mahasiswa
-- ----------------------------
DROP TABLE IF EXISTS `tb_mahasiswa`;
CREATE TABLE `tb_mahasiswa`  (
  `mhs_id` int(10) NOT NULL AUTO_INCREMENT,
  `mhs_nim` tinytext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `mhs_nama` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `mhs_angkatan` year NULL DEFAULT NULL,
  PRIMARY KEY (`mhs_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_mahasiswa
-- ----------------------------
INSERT INTO `tb_mahasiswa` VALUES (1, '20180001', 'Jono', 2018);
INSERT INTO `tb_mahasiswa` VALUES (2, '20180002', 'Taufik', 2018);
INSERT INTO `tb_mahasiswa` VALUES (3, '20180003', 'Maria', 2018);
INSERT INTO `tb_mahasiswa` VALUES (4, '20190001', 'Sari', 2019);
INSERT INTO `tb_mahasiswa` VALUES (5, '20190002', 'Bambang', 2019);

-- ----------------------------
-- Table structure for tb_mahasiswa_nilai
-- ----------------------------
DROP TABLE IF EXISTS `tb_mahasiswa_nilai`;
CREATE TABLE `tb_mahasiswa_nilai`  (
  `mhs_nilai_id` int(10) NOT NULL AUTO_INCREMENT,
  `mhs_id` int(10) NULL DEFAULT NULL,
  `mk_id` int(10) NULL DEFAULT NULL,
  `nilai` int(10) NULL DEFAULT NULL,
  PRIMARY KEY (`mhs_nilai_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_mahasiswa_nilai
-- ----------------------------
INSERT INTO `tb_mahasiswa_nilai` VALUES (1, 1, 1, 70);
INSERT INTO `tb_mahasiswa_nilai` VALUES (2, 1, 2, 76);
INSERT INTO `tb_mahasiswa_nilai` VALUES (3, 2, 1, 82);
INSERT INTO `tb_mahasiswa_nilai` VALUES (4, 2, 2, 74);
INSERT INTO `tb_mahasiswa_nilai` VALUES (5, 4, 1, 78);
INSERT INTO `tb_mahasiswa_nilai` VALUES (6, 4, 2, 80);
INSERT INTO `tb_mahasiswa_nilai` VALUES (7, 5, 1, 60);

-- ----------------------------
-- Table structure for tb_matakuliah
-- ----------------------------
DROP TABLE IF EXISTS `tb_matakuliah`;
CREATE TABLE `tb_matakuliah`  (
  `mk_id` int(10) NOT NULL AUTO_INCREMENT,
  `mk_kode` tinytext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `mk_sks` int(3) NULL DEFAULT NULL,
  `mk_nama` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  PRIMARY KEY (`mk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_matakuliah
-- ----------------------------
INSERT INTO `tb_matakuliah` VALUES (1, 'MK202', 3, 'OOP');
INSERT INTO `tb_matakuliah` VALUES (2, 'MK303', 2, 'Basis Data');

-- ----------------------------
-- Table structure for tb_user
-- ----------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user`  (
  `us_id` int(10) NOT NULL AUTO_INCREMENT,
  `us_username` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `us_password` longtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  PRIMARY KEY (`us_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_user
-- ----------------------------
INSERT INTO `tb_user` VALUES (1, 'admin', 'admin');

SET FOREIGN_KEY_CHECKS = 1;
